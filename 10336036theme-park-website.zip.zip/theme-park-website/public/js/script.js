document.addEventListener('DOMContentLoaded', () => {
    const form = document.querySelector('form');
    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const messageInput = document.getElementById('message');

    form.addEventListener('submit', (event) => {
        let isValid = true;

        // Validate Contact Name
        if (nameInput.value.trim() === '') {
            displayError(nameInput, 'Name is required');
            isValid = false;
        } else {
            clearError(nameInput);
        }

        // Validate User Email
        if (!isValidEmail(emailInput.value)) {
            displayError(emailInput, 'Please enter a valid email address');
            isValid = false;
        } else {
            clearError(emailInput);
        }

        // Validate Message
        if (messageInput.value.trim() === '') {
            displayError(messageInput, 'Message is required');
            isValid = false;
        } else {
            clearError(messageInput);
        }

        // If the form is not valid, prevent submission
        if (!isValid) {
            event.preventDefault();
        }
    });

    function displayError(inputElement, message) {
        const parent = inputElement.parentElement;
        let errorElement = parent.querySelector('.error-message');
        
        if (!errorElement) {
            errorElement = document.createElement('span');
            errorElement.classList.add('error-message');
            parent.appendChild(errorElement);
        }
        
        errorElement.textContent = message;
        inputElement.classList.add('input-error');
    }

    function clearError(inputElement) {
        const parent = inputElement.parentElement;
        const errorElement = parent.querySelector('.error-message');
        
        if (errorElement) {
            parent.removeChild(errorElement);
        }
        
        inputElement.classList.remove('input-error');
    }

    function isValidEmail(email) {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailPattern.test(email);
    }
});
