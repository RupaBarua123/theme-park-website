const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./data/theme_park.db');

db.serialize(() => {
    // Create the areas table if it doesn't exist
    db.run(`CREATE TABLE IF NOT EXISTS areas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        image TEXT
    )`);

    // Create the rides table if it doesn't exist
    db.run(`CREATE TABLE IF NOT EXISTS rides (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        area_id INTEGER,
        name TEXT NOT NULL,
        description TEXT,
        image TEXT,
        FOREIGN KEY (area_id) REFERENCES areas(id)
    )`);

    // Create the contacts table if it doesn't exist
    db.run(`CREATE TABLE IF NOT EXISTS contacts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        message TEXT NOT NULL
    )`);

    // Insert some sample data for areas (if necessary)
    db.get("SELECT COUNT(*) AS count FROM areas", (err, row) => {
        if (err) throw err;

        // Insert data only if the areas table is empty
        if (row.count === 0) {
            console.log('Inserting sample data...');

            db.run(`INSERT INTO areas (name, description, image) VALUES
                ('Adventure World', 'An exciting world full of thrill rides.', '/images/advanture.webp'),
                ('Fantasy Land', 'A magical area filled with rides for kids and families.', '/images/fantasy.jpg'),
                ('Water Kingdom', 'Cool off with exciting water rides and attractions.', '/images/water.jpg')`);

            db.run(`INSERT INTO rides (area_id, name, description, image) VALUES
                (1, 'Dragon Roller Coaster', 'A thrilling roller coaster with high-speed turns.', '/images/dragon.jpg'),
                (1, 'Sky Tower', 'A drop tower that will leave your heart pounding.', '/images/sky.jpg'),
                (2, 'Merry-Go-Round', 'A classic carousel ride for kids.', '/images/marry.jpg'),
                (2, 'Flying Elephants', 'Take a ride in the air on the flying elephants.', '/images/elephant.jpg'),
                (3, 'Wave Pool', 'A fun water pool with artificially created waves.', '/images/wave.jpg'),
                (3, 'Lazy River', 'Relax and float along the gentle current of the lazy river.', '/images/river.jpg'),
                (1, 'Roller Madness', 'A fast-paced ride with loops and twists.', '/images/madness.jpg'),
                (2, 'Haunted House', 'Enter if you dare!', '/images/house.jpg')`);
        }
    });
});

module.exports = db;
