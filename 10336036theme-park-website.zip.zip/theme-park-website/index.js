const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const db = require('./data/db'); // Database connection

const app = express();

// Set EJS as the templating engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware to serve static files (CSS, JS, Images)
app.use(express.static(path.join(__dirname, 'public')));

// Middleware to parse URL-encoded form data
app.use(bodyParser.urlencoded({ extended: true }));

// Import and use the routes from the routes folder
app.use('/', require('./routes/index'));

// Start the server on port 5000 or environment-defined port
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
