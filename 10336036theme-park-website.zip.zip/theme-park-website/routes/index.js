const express = require('express');
const router = express.Router();
const db = require('../data/db'); // Import the database connection

// Home page route
router.get('/', (req, res) => {
    res.render('index', { title: 'Home' });
});

// Areas page route
router.get('/areas', (req, res) => {
    db.all('SELECT * FROM areas', (err, rows) => {
        if (err) throw err;
        res.render('areas', { title: 'Areas', areas: rows });
    });
});


// Rides page route
router.get('/rides/:areaId', (req, res) => {
    const areaId = req.params.areaId;
    db.all('SELECT * FROM rides WHERE area_id = ?', [areaId], (err, rows) => {
        if (err) throw err;
        res.render('rides', { title: 'Rides', rides: rows });
    });
});

// FAQ page route
router.get('/faq', (req, res) => {
    res.render('faq', { title: 'FAQ' });
});

// Contact us page route
// router.get('/contact', (req, res) => {
//     res.render('contact', { title: 'Contact Us' });
// });

// Contact us page route
router.get('/contact', (req, res) => {
    res.render('contact', { title: 'Contact Us', query: req.query });
});

// Handle contact form submission
router.post('/contact', (req, res) => {
    const { name, email, message } = req.body;
    db.run('INSERT INTO contacts (name, email, message) VALUES (?, ?, ?)', [name, email, message], (err) => {
        if (err) throw err;
        res.redirect('/contact?success=true');
    });
});

module.exports = router;
